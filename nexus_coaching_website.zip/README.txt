NEXUS ACADEMY — IIT JEE & NEET WEBSITE

FILES
- index.html : website structure and content
- style.css  : responsive design and styling
- script.js  : mobile navigation, year, back-to-top and demo enquiry form

HOW TO RUN
1. Keep all three files in the same folder.
2. Double-click index.html, or open it with VS Code and use Live Server.
3. Edit the placeholder institute name, email, phone, address, faculty and course details.

BEFORE PUBLISHING
- Replace Nexus Academy with your actual institute name and logo.
- Add verified faculty profiles, address, phone, email, batch timings, fee details and genuine results.
- The enquiry form currently opens the visitor's email app using a mailto link. It does not save enquiries to a database. Connect Formspree, Google Forms, a CRM or your own backend for live submissions.
- Add your privacy policy and terms, and test the site on mobile.
