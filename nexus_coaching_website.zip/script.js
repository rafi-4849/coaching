const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

menuToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
});

document.querySelectorAll('#navLinks a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
  });
});

document.getElementById('year').textContent = new Date().getFullYear();

const backTop = document.querySelector('.back-top');
window.addEventListener('scroll', () => {
  backTop.classList.toggle('visible', window.scrollY > 450);
});

// Front-end demo: opens the visitor's email application.
// Replace this with your backend/API or a form service for live lead collection.
document.getElementById('enquiryForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;

  const data = new FormData(form);
  const subject = encodeURIComponent('New admission enquiry - Nexus Academy');
  const body = encodeURIComponent(
    `Student name: ${data.get('studentName')}\n` +
    `Mobile: ${data.get('phone')}\n` +
    `Current class: ${data.get('classLevel')}\n` +
    `Interested course: ${data.get('course')}\n` +
    `Message: ${data.get('message') || 'Not provided'}`
  );

  // Update this address to your real admissions email before publishing.
  window.location.href = `mailto:admissions@yourinstitute.com?subject=${subject}&body=${body}`;
  document.getElementById('formStatus').textContent =
    'Your email app should open with the enquiry details. Configure a real admissions email or connect a form backend before launch.';
});
